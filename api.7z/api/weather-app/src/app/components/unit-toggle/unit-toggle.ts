import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-unit-toggle',
  templateUrl: './unit-toggle.component.html',
})
export class UnitToggleComponent {
  @Output() unitChange = new EventEmitter<'C' | 'F'>();
  current: 'C' | 'F' = 'C';

  toggle() {
    this.current = this.current === 'C' ? 'F' : 'C';
    this.unitChange.emit(this.current);
  }
}
