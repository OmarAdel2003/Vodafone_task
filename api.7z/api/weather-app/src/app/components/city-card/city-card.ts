import { Component, Input } from '@angular/core';
import { City } from '../../models/city.model';

@Component({
  selector: 'app-city-card',
  templateUrl: './city-card.component.html',
})
export class CityCardComponent {
  @Input() city!: City;
  @Input() unit: 'C' | 'F' = 'C';

  get latest() {
    return this.city.forecast[this.city.forecast.length - 1];
  }
}
