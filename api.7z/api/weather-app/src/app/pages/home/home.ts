import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../../services/weather.service';
import { City } from '../../models/city.model';

@Component({
  templateUrl: './home.html',
})
export class HomeComponent implements OnInit {
  cities: City[] = [];
  filteredCities: City[] = [];
  selectedDate: string | null = null;
  unit: 'C' | 'F' = 'C';

  constructor(private weatherService: WeatherService) {}

  ngOnInit() {
    this.weatherService.getAllCities().subscribe(data => {
      this.cities = data;
      this.filteredCities = data;
    });
  }

  onSearch(cityName: string) {
    this.filteredCities = this.cities.filter(c =>
      c.city.toLowerCase().includes(cityName.toLowerCase())
    );
  }

  onUnitChange(u: 'C' | 'F') {
    this.unit = u;
  }

  onDateChange(event: any) {
    this.selectedDate = event.target.value;

    this.filteredCities = this.cities.map(city => ({
      ...city,
      forecast: city.forecast.filter(f => f.date === this.selectedDate)
    })).filter(c => c.forecast.length);
  }
}
