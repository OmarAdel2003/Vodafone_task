import { City } from './citymodel';

describe('City', () => {
  it('should create an instance', () => {
    expect(new City()).toBeTruthy();
  });
});
