import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { City } from '../models/city.model';

@Injectable({ providedIn: 'root' })
export class WeatherService {
  private api = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  getAllCities(): Observable<City[]> {
    return this.http.get<City[]>(`${this.api}/forecast`);
  }

  getCityById(id: number): Observable<City> {
    return this.http.get<City>(`${this.api}/cityForecast/${id}`);
  }
}
